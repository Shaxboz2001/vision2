import React, { useEffect, useRef, useState, useCallback } from "react";

const WS_URL = "wss://172.16.55.13:8009/ai_lom";
const BASE_RECONNECT_DELAY = 1_000;
const MAX_RECONNECT_DELAY = 30_000;

export default function AILom() {
  const wsRef = useRef(null);
  const imgRef = useRef(null);
  const reconnectTimerRef = useRef(null);
  const prevUrlRef = useRef(null);
  const mountedRef = useRef(true);
  const attemptRef = useRef(0);

  const [status, setStatus] = useState("connecting");

  const clearReconnect = useCallback(() => {
    if (reconnectTimerRef.current) {
      clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
  }, []);

  const closeSocket = useCallback(() => {
    const ws = wsRef.current;
    if (!ws) return;
    ws.onopen = ws.onmessage = ws.onerror = ws.onclose = null;
    try {
      if (
        ws.readyState === WebSocket.OPEN ||
        ws.readyState === WebSocket.CONNECTING
      ) {
        ws.close();
      }
    } catch (_) {}
    wsRef.current = null;
  }, []);

  const scheduleReconnect = useCallback(() => {
    clearReconnect();
    const attempt = attemptRef.current++;
    const delay = Math.min(
      BASE_RECONNECT_DELAY * 2 ** attempt,
      MAX_RECONNECT_DELAY,
    );
    reconnectTimerRef.current = setTimeout(() => {
      if (mountedRef.current && !document.hidden) connect();
    }, delay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const connect = useCallback(() => {
    clearReconnect();
    closeSocket();
    if (!mountedRef.current || document.hidden) return;

    setStatus("connecting");

    let ws;
    try {
      ws = new WebSocket(WS_URL);
    } catch (err) {
      console.error("WS create error:", err);
      setStatus("error");
      scheduleReconnect();
      return;
    }
    ws.binaryType = "blob";
    wsRef.current = ws;

    ws.onopen = () => {
      if (!mountedRef.current) return;
      attemptRef.current = 0;
      setStatus("live");
    };

    ws.onmessage = (event) => {
      if (!mountedRef.current || !imgRef.current) return;

      // event.data ALLAQACHON Blob (binaryType="blob") — qayta o'ramaymiz
      const blob =
        event.data instanceof Blob
          ? event.data
          : new Blob([event.data], { type: "image/jpeg" });

      const url = URL.createObjectURL(blob);
      const img = imgRef.current;
      const oldUrl = prevUrlRef.current;

      // Eski URL'ni faqat yangi frame decode bo'lgandan keyin revoke qilamiz
      // → flicker yo'q, memory leak yo'q
      img.onload = () => {
        if (oldUrl) URL.revokeObjectURL(oldUrl);
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
      };

      prevUrlRef.current = url;
      img.src = url;
    };

    ws.onerror = (err) => {
      console.error("WS error:", err);
      if (mountedRef.current) setStatus("error");
    };

    ws.onclose = () => {
      if (!mountedRef.current) return;
      setStatus("connecting");
      scheduleReconnect();
    };
  }, [clearReconnect, closeSocket, scheduleReconnect]);

  useEffect(() => {
    mountedRef.current = true;
    connect();

    const onVisibility = () => {
      if (document.hidden) {
        clearReconnect();
        closeSocket();
        setStatus("connecting");
      } else {
        attemptRef.current = 0;
        connect();
      }
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      mountedRef.current = false;
      document.removeEventListener("visibilitychange", onVisibility);
      clearReconnect();
      closeSocket();
      if (prevUrlRef.current) {
        URL.revokeObjectURL(prevUrlRef.current);
        prevUrlRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const bg = {
    live: "rgba(22,163,74,0.9)",
    error: "rgba(220,38,38,0.9)",
    connecting: "rgba(245,158,11,0.9)",
  }[status];

  const label = {
    live: "● LIVE",
    error: "● XATO",
    connecting: "● ULANMOQDA",
  }[status];

  return (
    <div
      style={{
        width: "100%",
        minHeight: "calc(100vh - 64px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
        boxSizing: "border-box",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: 1400,
          borderRadius: 20,
          overflow: "hidden",
          position: "relative",
          background: "#000",
          boxShadow: "0 10px 30px rgba(0,0,0,0.25)",
        }}
      >
        <img
          ref={imgRef}
          alt="camera"
          style={{
            width: "100%",
            height: "calc(100vh - 110px)",
            objectFit: "cover",
            display: "block",
            background: "#000",
          }}
        />
        <div
          style={{
            position: "absolute",
            top: 14,
            left: 14,
            padding: "8px 14px",
            borderRadius: 999,
            background: bg,
            color: "#fff",
            fontSize: 13,
            fontWeight: 700,
            backdropFilter: "blur(6px)",
          }}
        >
          {label}
        </div>
      </div>
    </div>
  );
}
