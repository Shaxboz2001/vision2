import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Box,
  Grid,
  Paper,
  Typography,
  LinearProgress,
  Divider,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  useTheme,
} from "@mui/material";
// import { getUchastkalar, getUskunalar } from "@/api";
import {
  getSexlarHybrid,
  getUchastkalarHybrid,
  getUskunalarHybrid,
} from "@/api/hybrid";
import {
  StatusChip,
  SectionHeader,
  StatBox,
  CardSkeleton,
} from "@/components/common";
import { setSelectedSex } from "@/store";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useScriptText } from "../../hooks/useScriptText";

// ─── SVG ILLUSTRATSIYALAR ───────────────────────────────────────────
const SexSVG = {
  "SEX-01": ({ color = "#ff6b1a", pulse = false }) => (
    <svg
      viewBox="0 0 120 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: "100%", height: "100%" }}
    >
      {/* Domna pechi */}
      <rect
        x="40"
        y="30"
        width="40"
        height="45"
        rx="4"
        fill={color}
        opacity="0.15"
        stroke={color}
        strokeWidth="1.5"
      />
      <path
        d="M45 30 Q60 10 75 30"
        fill={color}
        opacity="0.2"
        stroke={color}
        strokeWidth="1.5"
      />
      <rect
        x="52"
        y="60"
        width="6"
        height="15"
        rx="2"
        fill={color}
        opacity="0.5"
      />
      <rect
        x="62"
        y="60"
        width="6"
        height="15"
        rx="2"
        fill={color}
        opacity="0.5"
      />
      {/* Olov */}
      <path
        d="M55 35 Q58 28 60 32 Q62 26 65 30 Q67 24 60 20 Q53 24 55 35Z"
        fill="#ff2d55"
        opacity="0.7"
      >
        {pulse && (
          <animate
            attributeName="opacity"
            values="0.7;0.4;0.7"
            dur="1.5s"
            repeatCount="indefinite"
          />
        )}
      </path>
      {/* Tutun */}
      <circle cx="50" cy="14" r="4" fill={color} opacity="0.12" />
      <circle cx="60" cy="8" r="5" fill={color} opacity="0.08" />
      <circle cx="70" cy="12" r="3" fill={color} opacity="0.1" />
      {/* Quvur */}
      <rect
        x="20"
        y="45"
        width="20"
        height="6"
        rx="3"
        fill={color}
        opacity="0.3"
      />
      <rect
        x="80"
        y="50"
        width="20"
        height="6"
        rx="3"
        fill={color}
        opacity="0.3"
      />
      {/* Taglik */}
      <rect
        x="35"
        y="75"
        width="50"
        height="3"
        rx="1.5"
        fill={color}
        opacity="0.25"
      />
    </svg>
  ),

  "SEX-02": ({ color = "#00d4ff", pulse = false }) => (
    <svg
      viewBox="0 0 120 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: "100%", height: "100%" }}
    >
      {/* Konverter silindr */}
      <ellipse
        cx="60"
        cy="28"
        rx="22"
        ry="10"
        fill={color}
        opacity="0.15"
        stroke={color}
        strokeWidth="1.5"
      />
      <rect
        x="38"
        y="28"
        width="44"
        height="38"
        fill={color}
        opacity="0.1"
        stroke={color}
        strokeWidth="1.5"
      />
      <ellipse
        cx="60"
        cy="66"
        rx="22"
        ry="8"
        fill={color}
        opacity="0.15"
        stroke={color}
        strokeWidth="1.2"
      />
      {/* Lance quvur */}
      <rect
        x="57"
        y="5"
        width="6"
        height="30"
        rx="3"
        fill={color}
        opacity="0.5"
      />
      <circle cx="60" cy="7" r="4" fill={color} opacity="0.3" />
      {/* Qizil po'lat chiqishi */}
      <path d="M82 50 Q95 48 100 52 Q98 56 82 56Z" fill="#ff6b1a" opacity="0.5">
        {pulse && (
          <animate
            attributeName="d"
            values="M82 50 Q95 48 100 52 Q98 56 82 56Z;M82 50 Q96 47 102 51 Q100 57 82 56Z;M82 50 Q95 48 100 52 Q98 56 82 56Z"
            dur="2s"
            repeatCount="indefinite"
          />
        )}
      </path>
      {/* Oksigen trubkasi */}
      <path
        d="M20 20 Q30 30 38 35"
        stroke={color}
        strokeWidth="2"
        strokeDasharray="4,3"
        opacity="0.4"
      />
      {/* O'lchov asbob */}
      <rect
        x="25"
        y="40"
        width="8"
        height="12"
        rx="2"
        fill={color}
        opacity="0.2"
        stroke={color}
        strokeWidth="1"
      />
      <rect
        x="87"
        y="35"
        width="8"
        height="12"
        rx="2"
        fill={color}
        opacity="0.2"
        stroke={color}
        strokeWidth="1"
      />
    </svg>
  ),

  "SEX-03": ({ color = "#a78bfa", pulse = false }) => (
    <svg
      viewBox="0 0 120 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: "100%", height: "100%" }}
    >
      {/* Elektr pech korpus */}
      <rect
        x="30"
        y="25"
        width="60"
        height="50"
        rx="5"
        fill={color}
        opacity="0.12"
        stroke={color}
        strokeWidth="1.5"
      />
      {/* Elektrodlar */}
      <rect
        x="45"
        y="10"
        width="5"
        height="30"
        rx="2.5"
        fill={color}
        opacity="0.5"
      />
      <rect
        x="57"
        y="8"
        width="5"
        height="32"
        rx="2.5"
        fill={color}
        opacity="0.6"
      />
      <rect
        x="69"
        y="10"
        width="5"
        height="30"
        rx="2.5"
        fill={color}
        opacity="0.5"
      />
      {/* Uchqun */}
      <circle cx="47" cy="40" r="3" fill="#ffd60a" opacity="0.8">
        {pulse && (
          <animate
            attributeName="opacity"
            values="0.8;0.2;0.8"
            dur="0.8s"
            repeatCount="indefinite"
          />
        )}
      </circle>
      <circle cx="59" cy="38" r="4" fill="#ffd60a" opacity="0.9">
        {pulse && (
          <animate
            attributeName="opacity"
            values="0.9;0.1;0.9"
            dur="0.6s"
            repeatCount="indefinite"
          />
        )}
      </circle>
      <circle cx="71" cy="40" r="3" fill="#ffd60a" opacity="0.8">
        {pulse && (
          <animate
            attributeName="opacity"
            values="0.8;0.3;0.8"
            dur="1s"
            repeatCount="indefinite"
          />
        )}
      </circle>
      {/* Tok kabellari */}
      <path
        d="M15 15 Q25 20 30 30"
        stroke={color}
        strokeWidth="2"
        opacity="0.3"
        strokeLinecap="round"
      />
      <path
        d="M105 15 Q95 20 90 30"
        stroke={color}
        strokeWidth="2"
        opacity="0.3"
        strokeLinecap="round"
      />
      {/* Chiqindi */}
      <rect
        x="30"
        y="65"
        width="14"
        height="10"
        rx="2"
        fill={color}
        opacity="0.2"
        stroke={color}
        strokeWidth="1"
      />
    </svg>
  ),

  "SEX-04": ({ color = "#00ff9d", pulse = false }) => (
    <svg
      viewBox="0 0 120 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: "100%", height: "100%" }}
    >
      {/* Prokatka rolikları */}
      {[20, 38, 56, 74, 92].map((x, i) => (
        <g key={i}>
          <rect
            x={x}
            y="30"
            width="10"
            height="24"
            rx="5"
            fill={color}
            opacity="0.3"
            stroke={color}
            strokeWidth="1.2"
          />
          <circle cx={x + 5} cy="42" r="4" fill={color} opacity="0.5">
            {pulse && (
              <animateTransform
                attributeName="transform"
                type="rotate"
                from={`0 ${x + 5} 42`}
                to={`360 ${x + 5} 42`}
                dur={`${1 + i * 0.1}s`}
                repeatCount="indefinite"
              />
            )}
          </circle>
        </g>
      ))}
      {/* Metall tasmasi */}
      <rect
        x="10"
        y="40"
        width="100"
        height="6"
        rx="3"
        fill={color}
        opacity="0.2"
      />
      <rect
        x="10"
        y="40"
        width="60"
        height="6"
        rx="3"
        fill={color}
        opacity="0.4"
      >
        {pulse && (
          <animate
            attributeName="width"
            values="60;80;60"
            dur="1.5s"
            repeatCount="indefinite"
          />
        )}
      </rect>
      {/* Krепеж */}
      <rect
        x="10"
        y="20"
        width="100"
        height="8"
        rx="2"
        fill={color}
        opacity="0.1"
        stroke={color}
        strokeWidth="1"
      />
      <rect
        x="10"
        y="58"
        width="100"
        height="8"
        rx="2"
        fill={color}
        opacity="0.1"
        stroke={color}
        strokeWidth="1"
      />
      {/* Temperatura sensori */}
      <circle
        cx="15"
        cy="55"
        r="5"
        fill="#ff6b1a"
        opacity="0.4"
        stroke="#ff6b1a"
        strokeWidth="1"
      />
    </svg>
  ),

  "SEX-05": ({ color = "#ff2d55", pulse = false }) => (
    <svg
      viewBox="0 0 120 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: "100%", height: "100%" }}
    >
      {/* Quyish krychagi */}
      <path
        d="M20 20 L50 20 L55 35 L65 35 L70 20 L100 20"
        stroke={color}
        strokeWidth="2.5"
        opacity="0.4"
        strokeLinecap="round"
      />
      <rect
        x="45"
        y="35"
        width="30"
        height="20"
        rx="3"
        fill={color}
        opacity="0.15"
        stroke={color}
        strokeWidth="1.5"
      />
      {/* Kran */}
      <rect
        x="55"
        y="5"
        width="10"
        height="30"
        rx="5"
        fill={color}
        opacity="0.3"
        stroke={color}
        strokeWidth="1.2"
      />
      {/* Eritilgan metall (nosoz holatda qizil) */}
      <path d="M48 52 Q60 65 72 52" fill={color} opacity="0.35">
        {pulse && (
          <animate
            attributeName="opacity"
            values="0.35;0.1;0.35"
            dur="2s"
            repeatCount="indefinite"
          />
        )}
      </path>
      {/* Xato belgisi */}
      <circle
        cx="95"
        cy="20"
        r="10"
        fill="#ff2d55"
        opacity="0.15"
        stroke="#ff2d55"
        strokeWidth="1.5"
      />
      <path
        d="M90 15 L100 25 M100 15 L90 25"
        stroke="#ff2d55"
        strokeWidth="2"
        strokeLinecap="round"
        opacity="0.7"
      />
      {/* Qoliplar */}
      <rect
        x="15"
        y="55"
        width="16"
        height="20"
        rx="2"
        fill={color}
        opacity="0.1"
        stroke={color}
        strokeWidth="1"
      />
      <rect
        x="35"
        y="58"
        width="16"
        height="17"
        rx="2"
        fill={color}
        opacity="0.1"
        stroke={color}
        strokeWidth="1"
      />
    </svg>
  ),

  "SEX-06": ({ color = "#6b7280", pulse = false }) => (
    <svg
      viewBox="0 0 120 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: "100%", height: "100%" }}
    >
      {/* Dastgoh */}
      <rect
        x="25"
        y="20"
        width="70"
        height="45"
        rx="4"
        fill={color}
        opacity="0.08"
        stroke={color}
        strokeWidth="1.5"
        strokeDasharray="5,3"
      />
      {/* Tokar dastgohi */}
      <rect
        x="35"
        y="30"
        width="50"
        height="20"
        rx="3"
        fill={color}
        opacity="0.12"
        stroke={color}
        strokeWidth="1"
      />
      <circle
        cx="50"
        cy="40"
        r="8"
        fill={color}
        opacity="0.15"
        stroke={color}
        strokeWidth="1.2"
      />
      <circle cx="50" cy="40" r="4" fill={color} opacity="0.2" />
      <circle
        cx="80"
        cy="40"
        r="5"
        fill={color}
        opacity="0.15"
        stroke={color}
        strokeWidth="1"
      />
      {/* Kalit/asbob */}
      <path d="M65 30 L75 20 L80 25 L70 35Z" fill={color} opacity="0.25" />
      {/* To'xtatilgan belgisi */}
      <rect
        x="90"
        y="12"
        width="18"
        height="18"
        rx="4"
        fill={color}
        opacity="0.12"
        stroke={color}
        strokeWidth="1.2"
      />
      <rect
        x="95"
        y="17"
        width="8"
        height="8"
        rx="1"
        fill={color}
        opacity="0.4"
      />
      {/* Taglik */}
      <rect
        x="25"
        y="65"
        width="70"
        height="4"
        rx="2"
        fill={color}
        opacity="0.2"
      />
    </svg>
  ),
  "SEX-07": ({ pulse = false }) => (
    <svg
      viewBox="0 0 120 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: "100%", height: "100%" }}
    >
      <defs>
        {/* Korpus metall gradyenti */}
        <linearGradient
          id="korpus"
          x1="8"
          y1="22"
          x2="96"
          y2="68"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#4a5568" />
          <stop offset="40%" stopColor="#2d3748" />
          <stop offset="100%" stopColor="#1a202c" />
        </linearGradient>
        {/* Chap rulon (po'lat) */}
        <linearGradient
          id="rulon_l"
          x1="17"
          y1="36"
          x2="29"
          y2="36"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#718096" />
          <stop offset="30%" stopColor="#e2e8f0" />
          <stop offset="60%" stopColor="#a0aec0" />
          <stop offset="100%" stopColor="#4a5568" />
        </linearGradient>
        {/* O'ng rulon (po'lat) */}
        <linearGradient
          id="rulon_r"
          x1="75"
          y1="36"
          x2="87"
          y2="36"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#718096" />
          <stop offset="30%" stopColor="#e2e8f0" />
          <stop offset="60%" stopColor="#a0aec0" />
          <stop offset="100%" stopColor="#4a5568" />
        </linearGradient>
        {/* Yuqori bosim silindr (sariq po'lat) */}
        <linearGradient
          id="bosim_t"
          x1="44"
          y1="33"
          x2="60"
          y2="33"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#744210" />
          <stop offset="35%" stopColor="#f6c34b" />
          <stop offset="65%" stopColor="#d69e2e" />
          <stop offset="100%" stopColor="#744210" />
        </linearGradient>
        {/* Pastki bosim silindr */}
        <linearGradient
          id="bosim_b"
          x1="44"
          y1="47"
          x2="60"
          y2="47"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#744210" />
          <stop offset="35%" stopColor="#f6c34b" />
          <stop offset="65%" stopColor="#d69e2e" />
          <stop offset="100%" stopColor="#744210" />
        </linearGradient>
        {/* Nazorat paneli (ko'k) */}
        <linearGradient
          id="panel"
          x1="96"
          y1="10"
          x2="116"
          y2="38"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#2b4299" />
          <stop offset="100%" stopColor="#1a2a6c" />
        </linearGradient>
        {/* Taglik */}
        <linearGradient
          id="taglik"
          x1="8"
          y1="68"
          x2="96"
          y2="72"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#4a5568" />
          <stop offset="50%" stopColor="#718096" />
          <stop offset="100%" stopColor="#4a5568" />
        </linearGradient>
        {/* List lenta (qizil) */}
        <linearGradient
          id="list_grad"
          x1="29"
          y1="40"
          x2="75"
          y2="46"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#c0392b" />
          <stop offset="50%" stopColor="#e74c3c" />
          <stop offset="100%" stopColor="#c0392b" />
        </linearGradient>
        {/* Strelka */}
        <marker
          id="arr07c"
          viewBox="0 0 8 8"
          refX="6"
          refY="4"
          markerWidth="4"
          markerHeight="4"
          orient="auto"
        >
          <path
            d="M1 1L7 4L1 7"
            fill="none"
            stroke="#e2e8f0"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </marker>
      </defs>

      {/* Asosiy korpus */}
      <rect
        x="8"
        y="22"
        width="88"
        height="46"
        rx="4"
        fill="url(#korpus)"
        stroke="#718096"
        strokeWidth="0.8"
      />
      <rect
        x="9"
        y="22.5"
        width="86"
        height="1.5"
        rx="1"
        fill="#718096"
        opacity="0.5"
      />

      {/* Chap rulon bloki */}
      <rect
        x="13"
        y="30"
        width="20"
        height="30"
        rx="3"
        fill="#2d3748"
        stroke="#4a5568"
        strokeWidth="0.6"
      />
      <ellipse
        cx="23"
        cy="45"
        rx="7"
        ry="10"
        fill="url(#rulon_l)"
        stroke="#a0aec0"
        strokeWidth="0.5"
      />
      <line
        x1="23"
        y1="35.2"
        x2="23"
        y2="54.8"
        stroke="#4a5568"
        strokeWidth="0.6"
        opacity="0.7"
      />
      <ellipse
        cx="23"
        cy="45"
        rx="2"
        ry="2.8"
        fill="#2d3748"
        stroke="#718096"
        strokeWidth="0.5"
      />
      <circle cx="23" cy="45" r="1" fill="#e2e8f0" />

      {/* O'ng rulon bloki */}
      <rect
        x="71"
        y="30"
        width="20"
        height="30"
        rx="3"
        fill="#2d3748"
        stroke="#4a5568"
        strokeWidth="0.6"
      />
      <ellipse
        cx="81"
        cy="45"
        rx="7"
        ry="10"
        fill="url(#rulon_r)"
        stroke="#a0aec0"
        strokeWidth="0.5"
      />
      <line
        x1="81"
        y1="35.2"
        x2="81"
        y2="54.8"
        stroke="#4a5568"
        strokeWidth="0.6"
        opacity="0.7"
      />
      <ellipse
        cx="81"
        cy="45"
        rx="2"
        ry="2.8"
        fill="#2d3748"
        stroke="#718096"
        strokeWidth="0.5"
      />
      <circle cx="81" cy="45" r="1" fill="#e2e8f0" />

      {/* List lenta */}
      <path
        d="M30 43.5 Q41 40.5 52 43.5 Q63 46.5 74 43.5"
        stroke="url(#list_grad)"
        strokeWidth="3"
        strokeLinecap="round"
      />
      <path
        d="M30 43.5 Q41 40.5 52 43.5 Q63 46.5 74 43.5"
        stroke="#ff6b6b"
        strokeWidth="1"
        strokeLinecap="round"
        opacity="0.5"
      />
      <path
        d="M30 46 Q41 43 52 46 Q63 49 74 46"
        stroke="#922b21"
        strokeWidth="1.5"
        strokeLinecap="round"
        opacity="0.7"
      />

      {/* Yuqori bosim silindr */}
      <ellipse
        cx="52"
        cy="37"
        rx="9"
        ry="5.5"
        fill="url(#bosim_t)"
        stroke="#b7791f"
        strokeWidth="0.8"
      />
      <ellipse cx="52" cy="37" rx="3.5" ry="2" fill="#744210" opacity="0.6" />

      {/* Pastki bosim silindr */}
      <ellipse
        cx="52"
        cy="53"
        rx="9"
        ry="5.5"
        fill="url(#bosim_b)"
        stroke="#b7791f"
        strokeWidth="0.8"
      />
      <ellipse cx="52" cy="53" rx="3.5" ry="2" fill="#744210" opacity="0.6" />

      {/* Shatun */}
      <rect
        x="50"
        y="42"
        width="4"
        height="11"
        rx="1"
        fill="#4a5568"
        stroke="#718096"
        strokeWidth="0.5"
      />

      {/* Nazorat paneli */}
      <rect
        x="96"
        y="9"
        width="20"
        height="30"
        rx="3"
        fill="url(#panel)"
        stroke="#4299e1"
        strokeWidth="0.8"
      />
      <rect
        x="97"
        y="9.5"
        width="18"
        height="1"
        rx="0.5"
        fill="#63b3ed"
        opacity="0.5"
      />
      <circle
        cx="106"
        cy="16"
        r="3"
        fill="#38a169"
        stroke="#276749"
        strokeWidth="0.5"
      />
      <circle cx="106" cy="16" r="1.5" fill="#68d391" opacity="0.8" />
      <circle
        cx="106"
        cy="24"
        r="2.5"
        fill="#e53e3e"
        stroke="#9b2c2c"
        strokeWidth="0.5"
      />
      <circle cx="106" cy="24" r="1.2" fill="#fc8181" opacity="0.7" />
      <rect
        x="99"
        y="30"
        width="14"
        height="3"
        rx="1.5"
        fill="#2c5282"
        stroke="#4299e1"
        strokeWidth="0.4"
      />
      <rect
        x="103"
        y="29.5"
        width="4"
        height="4"
        rx="1"
        fill="#90cdf4"
        stroke="#4299e1"
        strokeWidth="0.4"
      />

      {/* Tezlik o'zgartgich */}
      <path
        d="M91 40 L100 36 L100 44 Z"
        fill="#f6c34b"
        stroke="#b7791f"
        strokeWidth="0.5"
      />

      {/* Kirish/chiqish strelkalar */}
      <path
        d="M1 45 L11 45"
        stroke="#e2e8f0"
        strokeWidth="1.2"
        strokeLinecap="round"
        markerEnd="url(#arr07c)"
      />
      <text x="1" y="42" fontSize="3.5" fill="#a0aec0" fontFamily="san-serif">
        IN
      </text>
      <path
        d="M93 45 L104 45"
        stroke="#e2e8f0"
        strokeWidth="1.2"
        strokeLinecap="round"
        markerEnd="url(#arr07c)"
      />
      <text x="95" y="42" fontSize="3.5" fill="#a0aec0" fontFamily="san-serif">
        OUT
      </text>

      {/* Taglik va oyoqlar */}
      <rect
        x="8"
        y="68"
        width="88"
        height="5"
        rx="2"
        fill="url(#taglik)"
        stroke="#4a5568"
        strokeWidth="0.6"
      />
      <rect
        x="14"
        y="73"
        width="6"
        height="7"
        rx="1.5"
        fill="#2d3748"
        stroke="#4a5568"
        strokeWidth="0.5"
      />
      <rect x="24" y="75" width="4" height="5" rx="1" fill="#4a5568" />
      <rect
        x="84"
        y="73"
        width="6"
        height="7"
        rx="1.5"
        fill="#2d3748"
        stroke="#4a5568"
        strokeWidth="0.5"
      />
      <rect x="76" y="75" width="4" height="5" rx="1" fill="#4a5568" />

      {/* Yer soyasi */}
      <ellipse cx="52" cy="81" rx="44" ry="2" fill="#000" opacity="0.2" />
    </svg>
  ),
};

// ─── SEX DETAIL PANEL ───────────────────────────────────────────────
function SexDetailPanel({ sex }) {
  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const { t } = useScriptText();
  // const { data: uch } = useQuery({
  //   queryKey: ["uchastkalar", sex.id],
  //   queryFn: () => getUchastkalar(sex.id),
  // });
  // const { data: usk } = useQuery({
  //   queryKey: ["uskunalar", sex.id],
  //   queryFn: () => getUskunalar({ sexId: sex.id }),
  // });
  const today = new Date().toISOString().split("T")[0];

  const { data: uch, isFetching: uchFetching } = useQuery({
    queryKey: ["uchastkalar", "hybrid", sex.id, today],
    queryFn: () =>
      getUchastkalarHybrid(sex.id, {
        startDate: today,
        endDate: today,
      }),
    refetchInterval: sex.id === "SEX-07" ? 60_000 : false,
    refetchOnWindowFocus: true,
  });

  const { data: usk, isFetching: uskFetching } = useQuery({
    queryKey: ["uskunalar", "hybrid", sex.id, today],
    queryFn: () =>
      getUskunalarHybrid(
        { sexId: sex.id },
        {
          startDate: today,
          endDate: today,
        },
      ),
    refetchInterval: sex.id === "SEX-07" ? 60_000 : false,
    refetchOnWindowFocus: true,
  });
  const uchastkalar = uch?.data || [];
  const uskunalar = usk?.data || [];

  return (
    <Box sx={{ p: 2 }}>
      <Grid container spacing={2} sx={{ mb: 2 }}>
        {[
          { l: "HOLAT", v: <StatusChip holat={sex.holat} /> },
          { l: "ISHCHILAR", v: sex.ishchilar, c: "primary.main" },
          {
            l: "HARORAT",
            v: `${sex.harorat}°C`,
            c: sex.harorat > 1400 ? "error.main" : "secondary.main",
          },
          {
            l: "YUK KO'RS.",
            v: `${sex.yuk}%`,
            c: sex.yuk > 90 ? "warning.main" : "success.main",
          },
          { l: "SMENA", v: sex.smena, c: "primary.main" },
        ].map((s) => (
          <Grid item xs={6} sm={2.4} key={s.l}>
            <Box
              sx={{
                background: isDark ? "rgba(0,0,0,0.2)" : "rgba(0,0,0,0.03)",
                border: "1px solid",
                borderColor: "divider",
                borderRadius: 1,
                p: 1.5,
                textAlign: "center",
              }}
            >
              <Typography
                sx={{
                  fontFamily: "'Arial',san-serif",
                  fontSize: "0.55rem",
                  color: "text.secondary",
                  letterSpacing: "0.1em",
                  mb: 0.5,
                }}
              >
                {t(s.l)}
              </Typography>
              {typeof s.v === "string" || typeof s.v === "number" ? (
                <Typography
                  sx={{
                    fontFamily: "'Arial',san-serif",
                    fontSize: "0.9rem",
                    color: s.c || "text.primary",
                  }}
                >
                  {t(s.v)}
                </Typography>
              ) : (
                t(s.v)
              )}
            </Box>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          <Typography
            sx={{
              fontFamily: "'Arial',san-serif",
              fontSize: "0.6rem",
              color: "text.secondary",
              letterSpacing: "0.15em",
              mb: 1,
            }}
          >
            {t("HUDUDLAR")}
          </Typography>
          {/* {uchastkalar.map((u) => (
            <Box
              key={u.id}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1.5,
                py: 0.8,
                borderBottom: "1px solid",
                borderColor: "divider",
              }}
            >
              <Typography
                sx={{
                  fontFamily: "'Arial',san-serif",
                  fontSize: "0.65rem",
                  color: "secondary.main",
                  minWidth: 70,
                }}
              >
                {u.id}
              </Typography>
              <Typography
                sx={{ fontSize: "0.8rem", flex: 1, color: "text.primary" }}
              >
                {u.nom}
              </Typography>
              <StatusChip holat={u.holat} />
              <Typography
                sx={{
                  fontFamily: "'Arial',san-serif",
                  fontSize: "0.65rem",
                  color: "text.secondary",
                }}
              >
                {u.harorat}°C
              </Typography>
            </Box>
          ))} */}
          {uchastkalar.map((u) => (
            <Box
              key={u.id}
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 1.5,
                py: 1,
                borderBottom: "1px solid",
                borderColor: "divider",
              }}
            >
              <Box sx={{ minWidth: 0 }}>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                  <Typography
                    sx={{
                      fontWeight: 600,
                      fontSize: "0.82rem",
                      color: "text.primary",
                    }}
                  >
                    {t(u.nom)}
                  </Typography>

                  {/* {u.live && (
                    <Typography
                      sx={{
                        fontFamily: "'Arial',san-serif",
                        fontSize: "0.55rem",
                        color: "#00e676",
                        px: 0.5,
                        py: 0.1,
                        border: "1px solid rgba(0,230,118,0.35)",
                        borderRadius: 0.5,
                        background: "rgba(0,230,118,0.08)",
                      }}
                    >
                      LIVE
                    </Typography>
                  )} */}
                </Box>

                <Typography
                  sx={{
                    fontFamily: "'Arial',san-serif",
                    fontSize: "0.62rem",
                    color: "text.secondary",
                    mt: 0.2,
                  }}
                >
                  {u.id} · {u.uskunalar} uskuna · {u.ishchilar} ishchi
                  {u.extraLabel ? ` · ${u.extraLabel}` : ""}
                </Typography>
              </Box>

              <Box sx={{ display: "flex", alignItems: "center", gap: 1.2 }}>
                {/* <Typography
                  sx={{
                    fontFamily: "'Arial',san-serif",
                    fontSize: "0.72rem",
                    color:
                      u.harorat > 1200
                        ? "error.main"
                        : u.harorat > 200
                          ? "secondary.main"
                          : "text.secondary",
                    minWidth: 64,
                    textAlign: "right",
                  }}
                >
                  {u.harorat}°C
                </Typography> */}

                <Typography
                  sx={{
                    fontFamily: "'Arial',san-serif",
                    fontSize: "0.72rem",
                    color:
                      u.samaradorlik >= 90
                        ? "success.main"
                        : u.samaradorlik >= 70
                          ? "warning.main"
                          : "error.main",
                    minWidth: 52,
                    textAlign: "right",
                  }}
                >
                  {u.samaradorlik}%
                </Typography>

                <StatusChip holat={u.holat} />
              </Box>
            </Box>
          ))}
        </Grid>
        <Grid item xs={12} md={6}>
          <Typography
            sx={{
              fontFamily: "'Arial',san-serif",
              fontSize: "0.6rem",
              color: "text.secondary",
              letterSpacing: "0.15em",
              mb: 1,
            }}
          >
            USKUNALAR
          </Typography>
          {uskunalar.map((u) => (
            <Box
              key={u.id}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1.5,
                py: 0.8,
                borderBottom: "1px solid",
                borderColor: "divider",
              }}
            >
              <Typography
                sx={{
                  fontFamily: "'Arial',san-serif",
                  fontSize: "0.65rem",
                  color: "primary.main",
                  minWidth: 70,
                }}
              >
                {u.id}
              </Typography>
              <Typography
                sx={{ fontSize: "0.8rem", flex: 1, color: "text.primary" }}
              >
                {u.nom}
              </Typography>
              <StatusChip holat={u.holat} />
              <Typography
                sx={{
                  fontFamily: "'Arial',san-serif",
                  fontSize: "0.65rem",
                  color: u.samaradorlik > 80 ? "success.main" : "warning.main",
                }}
              >
                {u.samaradorlik}%
              </Typography>
            </Box>
          ))}
        </Grid>
      </Grid>
    </Box>
  );
}

// ─── SEX KARTI ──────────────────────────────────────────────────────
const holatRang = {
  faol: "#00ff9d",
  ogohlantirish: "#ffd60a",
  xato: "#ff2d55",
  toxtagan: "#6b7280",
};
const svgColor = {
  "SEX-01": "#ff6b1a",
  "SEX-02": "#00d4ff",
  "SEX-03": "#a78bfa",
  "SEX-04": "#00ff9d",
  "SEX-05": "#ff2d55",
  "SEX-06": "#6b7280",
};

function SexCard({ s, selected, onClick }) {
  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const Illustration = SexSVG[s.id];
  const color = svgColor[s.id] || "#00d4ff";
  const isSelected = selected?.id === s.id;
  const { t } = useScriptText();
  const hasImage =
    s.id === "SEX-02" ||
    s.id === "SEX-07" ||
    s.id === "SEX-01" ||
    s.id === "SEX-03" ||
    s.id === "SEX-04" ||
    s.id === "SEX-05" ||
    s.id === "SEX-06" ||
    s.id === "SEX-09" ||
    s.id === "SEX-08";

  return (
    <Paper
      onClick={onClick}
      sx={{
        cursor: "pointer",
        borderRadius: 3,
        border: "1px solid",
        borderColor: isSelected
          ? color
          : isDark
            ? "rgba(255,255,255,0.06)"
            : "rgba(0,0,0,0.08)",
        boxShadow: isSelected
          ? `0 0 0 1px ${color}50, 0 8px 32px ${color}25`
          : isDark
            ? "0 2px 12px rgba(0,0,0,0.4)"
            : "0 2px 12px rgba(0,0,0,0.06)",
        transition: "all 0.35s cubic-bezier(0.4,0,0.2,1)",
        "&:hover": {
          borderColor: `${color}80`,
          transform: "translateY(-4px)",
          boxShadow: isDark
            ? `0 12px 40px ${color}20, 0 0 0 1px ${color}30`
            : `0 12px 40px ${color}15, 0 0 0 1px ${color}25`,
          "& .card-image": {
            transform: "scale(1.06)",
          },
          "& .card-glow": {
            opacity: 1,
          },
        },
        overflow: "hidden",
        position: "relative",
        background: isDark
          ? "linear-gradient(180deg, rgba(20,20,25,1) 0%, rgba(12,12,16,1) 100%)"
          : "linear-gradient(180deg, #eef0f4 0%, #e4e7ec 100%)",
      }}
    >
      {/* Hover glow effect */}
      <Box
        className="card-glow"
        sx={{
          position: "absolute",
          top: -1,
          left: "20%",
          right: "20%",
          height: 2,
          background: `linear-gradient(90deg, transparent, ${color}, transparent)`,
          opacity: isSelected ? 1 : 0,
          transition: "opacity 0.4s",
          zIndex: 5,
          borderRadius: "0 0 4px 4px",
        }}
      />

      {/* ═══ IMAGE AREA ═══ */}
      <Box
        sx={{
          height: 340,
          position: "relative",
          overflow: "hidden",
          background: isDark
            ? `radial-gradient(ellipse at 50% 40%, ${color}08 0%, rgba(10,10,14,1) 80%)`
            : `radial-gradient(ellipse at 50% 40%, ${color}06 0%, #e2e5ea 80%)`,
        }}
      >
        {/* Rasm */}
        <Box
          sx={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1,
          }}
        >
          {hasImage ? (
            <img
              className="card-image"
              src={`/images/bolimlar/${s.id}.png`}
              alt={s.nom}
              style={{
                width: "95%",
                height: "95%",
                objectFit: "contain",
                objectPosition: "center",
                transition: "transform 0.5s cubic-bezier(0.4,0,0.2,1)",
                willChange: "transform",
              }}
            />
          ) : (
            Illustration && (
              <Box
                className="card-image"
                sx={{
                  width: "80%",
                  height: "80%",
                  transition: "transform 0.5s cubic-bezier(0.4,0,0.2,1)",
                }}
              >
                <Illustration color={color} pulse={s.holat === "faol"} />
              </Box>
            )
          )}
        </Box>

        {/* Bottom edge fade — faqat pastki chiziq uchun */}
        <Box
          sx={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            height: "15%",
            background: isDark
              ? "linear-gradient(0deg, rgba(12,12,16,1) 0%, transparent 100%)"
              : "linear-gradient(0deg, #e4e7ec 0%, transparent 100%)",
            zIndex: 2,
          }}
        />

        {/* Top-right: LIVE + holat */}
        <Box
          sx={{
            position: "absolute",
            top: 14,
            right: 14,
            zIndex: 3,
            display: "flex",
            alignItems: "center",
            gap: 1,
          }}
        >
          {/* {s.live && (
            <Typography
              sx={{
                fontFamily: "'Arial', san-serif",
                fontSize: "0.65rem",
                fontWeight: 600,
                color: "#00e676",
                px: 1,
                py: 0.3,
                borderRadius: 1,
                border: "1px solid rgba(0,230,118,0.35)",
                background: "rgba(0,230,118,0.1)",

                letterSpacing: "0.1em",
              }}
            >
              ● LIVE
            </Typography>
          )} */}
          <Box
            sx={{
              width: 12,
              height: 12,
              borderRadius: "50%",
              background: holatRang[s.holat],
              boxShadow: `0 0 8px ${holatRang[s.holat]}, 0 0 20px ${holatRang[s.holat]}35`,
              animation:
                s.holat === "faol" ? "blink 1.5s ease-in-out infinite" : "none",
              "@keyframes blink": {
                "0%,100%": { opacity: 1 },
                "50%": { opacity: 0.3 },
              },
            }}
          />
        </Box>
      </Box>

      {/* ═══ INFO SECTION ═══ */}
      <Box sx={{ px: 2.5, pt: 1.5, pb: 2 }}>
        {/* Nom + Status */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            mb: 1.8,
          }}
        >
          <Typography
            sx={{
              fontWeight: 800,
              fontSize: "1.2rem",
              color: "text.primary",
              letterSpacing: "0.01em",
            }}
          >
            {t(s.nom)}
          </Typography>
          <StatusChip holat={t(s.holat)} />
        </Box>

        {/* STATS ROW */}
        <Grid container spacing={1} sx={{ mb: 2 }}>
          {[
            { l: "HUDUD", v: s.uchastkalar, c: color },
            {
              l: "USKUNA",
              v: `${s.faolUskunalar}/${s.uskunalar}`,
              c: "#ff6b1a",
            },
            { l: "ISHCHI", v: s.ishchilar, c: isDark ? "#00ff9d" : "#00a85a" },
            { l: "SMENA", v: "kun", c: isDark ? "#ffd60a" : "#d97700" },
          ].map((st) => (
            <Grid item xs={3} key={st.l}>
              <Box
                sx={{
                  textAlign: "center",
                  background: isDark
                    ? "rgba(255,255,255,0.03)"
                    : "rgba(0,0,0,0.025)",
                  borderRadius: 1.5,
                  py: 1,
                  border: "1px solid",
                  borderColor: isDark
                    ? "rgba(255,255,255,0.06)"
                    : "rgba(0,0,0,0.06)",
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "'Arial', san-serif",
                    fontSize: "1rem",
                    fontWeight: 700,
                    color: st.c,
                    lineHeight: 1.2,
                  }}
                >
                  {t(st.v)}
                </Typography>
                <Typography
                  sx={{
                    fontFamily: "'Arial', san-serif",
                    fontSize: "0.55rem",
                    color: "text.secondary",
                    letterSpacing: "0.08em",
                    mt: 0.3,
                  }}
                >
                  {t(st.l)}
                </Typography>
              </Box>
            </Grid>
          ))}
        </Grid>

        {/* YUK + HARORAT */}
        <Box sx={{ display: "flex", gap: 2, alignItems: "center" }}>
          <Box sx={{ flex: 1 }}>
            <Box
              sx={{ display: "flex", justifyContent: "space-between", mb: 0.5 }}
            >
              <Typography
                sx={{
                  fontFamily: "'Arial', san-serif",
                  fontSize: "0.65rem",
                  color: "text.secondary",
                  letterSpacing: "0.05em",
                }}
              >
                {t("YUK KO'RSATKICHI")}
              </Typography>
              <Typography
                sx={{
                  fontFamily: "'Arial', san-serif",
                  fontSize: "0.75rem",
                  fontWeight: 700,
                  color: s.yuk > 90 ? "warning.main" : color,
                }}
              >
                {s.yuk}%
              </Typography>
            </Box>
            <LinearProgress
              variant="determinate"
              value={s.yuk}
              sx={{
                height: 6,
                borderRadius: 3,
                backgroundColor: isDark
                  ? "rgba(255,255,255,0.05)"
                  : "rgba(0,0,0,0.06)",
                "& .MuiLinearProgress-bar": {
                  borderRadius: 3,
                  background:
                    s.yuk > 90
                      ? "linear-gradient(90deg, #ffd60a, #ff6b1a)"
                      : s.yuk > 0
                        ? `linear-gradient(90deg, ${color}80, ${color})`
                        : "#374151",
                },
              }}
            />
          </Box>

          {/* Harorat */}
          {/* <Box
            sx={{
              textAlign: "center",
              background: isDark
                ? "rgba(255,255,255,0.03)"
                : "rgba(0,0,0,0.025)",
              borderRadius: 1.5,
              px: 2,
              py: 0.8,
              border: "1px solid",
              borderColor:
                s.harorat > 1400
                  ? isDark
                    ? "rgba(255,45,85,0.4)"
                    : "rgba(255,45,85,0.3)"
                  : isDark
                    ? "rgba(255,255,255,0.06)"
                    : "rgba(0,0,0,0.06)",
              minWidth: 72,
            }}
          >
            <Typography
              sx={{
                fontFamily: "'Arial', san-serif",
                fontSize: "1rem",
                fontWeight: 700,
                color:
                  s.harorat > 1400
                    ? "error.main"
                    : s.harorat > 100
                      ? "secondary.main"
                      : "text.secondary",
                lineHeight: 1.2,
              }}
            >
              {s.harorat}°C
            </Typography>
            <Typography
              sx={{
                fontFamily: "'Arial', san-serif",
                fontSize: "0.48rem",
                color: "text.secondary",
                mt: 0.2,
              }}
            >
              HARORAT
            </Typography>
          </Box> */}
        </Box>
      </Box>
    </Paper>
  );
}

export default function Sexlar() {
  const [selected, setSelected] = useState(null);
  const { t } = useScriptText();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const today = new Date().toISOString().split("T")[0];

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ["sexlar", "hybrid", today],
    queryFn: () =>
      getSexlarHybrid({
        startDate: today,
        endDate: today,
      }),
    refetchInterval: 60_000,
    refetchOnWindowFocus: true,
  });

  const sexlar = data?.data || [];

  return (
    <Box sx={{ p: 2.5, display: "flex", flexDirection: "column", gap: 2 }}>
      {/* HEADER */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Box>
          <Typography
            sx={{
              fontFamily: "'Arial',san-serif",
              fontSize: "1.1rem",
              fontWeight: 700,
              letterSpacing: "0.15em",
              color: "text.primary",
            }}
          >
            {t("BO'LINMALAR BOSHQARUVI")}
          </Typography>
          <Typography
            sx={{
              fontFamily: "'Arial',san-serif",
              fontSize: "0.65rem",
              color: "text.secondary",
            }}
          >
            {t("Jami")} {sexlar.length} {t("bo'linma")} ·{" "}
            {sexlar.filter((s) => s.holat === "faol").length} {t("faol")} ·{" "}
            {sexlar.filter((s) => s.holat === "xato").length} {t("xato")}
          </Typography>
        </Box>

        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          {isFetching && (
            <Typography
              sx={{
                fontFamily: "'Arial',san-serif",
                fontSize: "0.6rem",
                color: "#00d4ff",
              }}
            >
              {t("Yangilanmoqda...")}
            </Typography>
          )}

          <Box sx={{ display: "flex", gap: 1.5 }}>
            {Object.entries(holatRang).map(([h, c]) => (
              <Box
                key={h}
                sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
              >
                <Box
                  sx={{
                    width: 7,
                    height: 7,
                    borderRadius: "50%",
                    background: c,
                    boxShadow: `0 0 5px ${c}`,
                  }}
                />
                <Typography
                  sx={{
                    fontFamily: "'Arial',san-serif",
                    fontSize: "0.6rem",
                    color: "text.secondary",
                    textTransform: "capitalize",
                  }}
                >
                  {h}
                </Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Box>

      {/* KARTALAR */}
      {isLoading ? (
        <CardSkeleton />
      ) : (
        <Grid container spacing={2}>
          {sexlar.map((s) => (
            <Grid item xs={12} sm={6} key={s.id}>
              <SexCard
                s={s}
                selected={selected}
                onClick={() => {
                  const newSelected = selected?.id === s.id ? null : s;

                  setSelected(newSelected);

                  if (newSelected) {
                    dispatch(setSelectedSex(newSelected));
                    navigate("/uchastkalar");
                  }
                }}
              />
            </Grid>
          ))}
        </Grid>
      )}

      <Paper>
        <SectionHeader title="Bo'linmalar Jadvali" dot="#ff6b1a" />
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>{t("BO'LINMALAR")}</TableCell>
              <TableCell>{t("HOLAT")}</TableCell>
              <TableCell>{t("HUDUDLAR")}</TableCell>
              <TableCell>{t("USKUNALAR")}</TableCell>
              <TableCell>{t("YUK")}</TableCell>
              {/* <TableCell>HARORAT</TableCell> */}
              <TableCell>{t("ISHCHILAR")}</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sexlar.map((s) => (
              <TableRow
                key={s.id}
                onClick={() => setSelected(selected?.id === s.id ? null : s)}
                sx={{ cursor: "pointer" }}
              >
                <TableCell>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Box sx={{ width: 28, height: 28, flexShrink: 0 }}>
                      {(() => {
                        const SvgIcon = SexSVG[s.id];
                        return SvgIcon ? (
                          <SvgIcon color={svgColor[s.id]} />
                        ) : null;
                      })()}
                    </Box>
                    <Box>
                      <Typography
                        sx={{
                          fontWeight: 600,
                          fontSize: "0.83rem",
                          color: "text.primary",
                        }}
                      >
                        {t(s.nom)}
                      </Typography>
                      {/* <Typography
                        sx={{
                          fontFamily: "'Arial',san-serif",
                          fontSize: "0.58rem",
                          color: "text.secondary",
                        }}
                      >
                        {s.id}
                      </Typography> */}
                    </Box>
                  </Box>
                </TableCell>
                <TableCell>
                  <StatusChip holat={s.holat} />
                </TableCell>
                <TableCell>
                  <Typography
                    sx={{
                      fontFamily: "'Arial',san-serif",
                      fontSize: "0.72rem",
                      color: "text.secondary",
                    }}
                  >
                    {s.uchastkalar} {t("ta")}
                  </Typography>
                </TableCell>
                <TableCell>
                  <Typography
                    sx={{
                      fontFamily: "'Arial',san-serif",
                      fontSize: "0.75rem",
                      color: "text.primary",
                    }}
                  >
                    {s.faolUskunalar}/{s.uskunalar}
                  </Typography>
                </TableCell>
                <TableCell>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                      minWidth: 110,
                    }}
                  >
                    <LinearProgress
                      variant="determinate"
                      value={s.yuk}
                      sx={{
                        flex: 1,
                        "& .MuiLinearProgress-bar": {
                          background:
                            s.yuk > 90
                              ? "#ffd60a"
                              : s.yuk > 0
                                ? svgColor[s.id]
                                : "#374151",
                        },
                      }}
                    />
                    <Typography
                      sx={{
                        fontFamily: "'Arial',san-serif",
                        fontSize: "0.65rem",
                        color: "text.secondary",
                        minWidth: 28,
                      }}
                    >
                      {s.yuk}%
                    </Typography>
                  </Box>
                </TableCell>
                {/* <TableCell>
                  <Typography
                    sx={{
                      fontFamily: "'Arial',san-serif",
                      fontSize: "0.75rem",
                      color:
                        s.harorat > 1400
                          ? "error.main"
                          : s.harorat > 200
                            ? "secondary.main"
                            : "text.secondary",
                    }}
                  >
                    {s.harorat}°C
                  </Typography>
                </TableCell> */}
                <TableCell>
                  <Typography
                    sx={{
                      fontFamily: "'Arial',san-serif",
                      fontSize: "0.75rem",
                      color: "success.main",
                    }}
                  >
                    {s.ishchilar}
                  </Typography>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>

      {/* DETAIL PANEL */}
      {selected && (
        <Paper sx={{ border: `1px solid ${svgColor[selected.id]}40` }}>
          <SectionHeader
            title={`${t(selected.nom)} — ${t("Batafsil Ma'lumot")}`}
            dot={svgColor[selected.id]}
            action={
              <span
                onClick={() => setSelected(null)}
                style={{ cursor: "pointer" }}
              >
                {t("✕ YOPISH")}
              </span>
            }
          />
          <SexDetailPanel sex={selected} />
        </Paper>
      )}
    </Box>
  );
}
